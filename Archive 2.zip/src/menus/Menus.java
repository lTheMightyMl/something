package menus;

public enum Menus {
    LOGIN_MENU,
    MAIN_MENU,
    COLLECTION,
    SHOP,
    BATTLE,
    SINGLE_PLAYER,
    MULTIPLAYER,
    STORY,
    CUSTOM_GAME,
    GAME_MENU,
    GRAVEYARD_MENU,
    LOGIN_ACCOUNT,
    CREATE_ACCOUNT,
}
