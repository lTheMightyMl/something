package menus;

public abstract class InGameMenu extends Menu {
/*    protected Game game;

    public static void setGame(Game game) {
        menus.InGameMenu.game = game;
    }*/
}
