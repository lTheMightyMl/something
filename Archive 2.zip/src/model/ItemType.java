package model;

public enum ItemType {
    CAST_A_SPELL,
    ADD_A_SPECIAL_POWER,
    ADD_MANA
}
