package model;

public enum UnitType {
    MELEE,
    RANGED,
    HYBRID
}
