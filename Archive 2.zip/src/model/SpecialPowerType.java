package model;

public enum SpecialPowerType {
    PASSIVE,
    ON_SPAWN,
    ON_ATTACK,
    ON_DEFEND,
    ON_DEATH,
    ON_HIT,
    COMBO,
    ON_USE
}
