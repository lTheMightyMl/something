package view;

import java.util.HashMap;
import java.util.Map;

public interface MenuComponent {
}