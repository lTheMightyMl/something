import model.Account;
import model.Match;
import model.Result;

import java.time.LocalDateTime;

public class Test {
    public static void main(String[] args) {
        System.out.println(new Match(new Account("SD", "ASD"), Result.WIN, LocalDateTime.now()));
    }
}
