package graphicControllers;

public interface OnMenuChangeListener {
    public void onMenuChanged(Menu newMenu);
}
