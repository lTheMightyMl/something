package graphicControllers;

public class MenuAlreadyCreatedException extends Exception {
    public MenuAlreadyCreatedException() {super("Menu has already been created!");}
}
